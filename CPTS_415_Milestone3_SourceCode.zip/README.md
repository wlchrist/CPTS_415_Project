# Initial setup

## Download dataset

1. Download "title.basics.tsv.gz" from [here](https://datasets.imdbws.com/)
2. Extract and add file to project folder
3. Create a python venv and run process_imdb_data.py
4. Data should now be extracted from .gz file